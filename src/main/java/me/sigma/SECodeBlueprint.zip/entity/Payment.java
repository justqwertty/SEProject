package me.sigma.entity;

import java.time.LocalDateTime;

public class Payment {
    private String paymentID;
    private String studentID;
    private float amount;
    private String paymentMethod;
    private LocalDateTime paymentDate;
    private String status;
    private String receiptNumber;

    public String getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(String paymentID) {
        this.paymentID = paymentID;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public LocalDateTime getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDateTime paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReceiptNumber() {
        return receiptNumber;
    }

    public void setReceiptNumber(String receiptNumber) {
        this.receiptNumber = receiptNumber;
    }

    public boolean processPayment() {
        return false;
    }

    public boolean validateFinancialAid() {
        return false;
    }

    public boolean connectToGateway(String method) {
        return false;
    }

    public boolean confirmPayment() {
        return false;
    }

    public Receipt generateReceipt() {
        return null;
    }
}
